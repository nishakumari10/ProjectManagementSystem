<!DOCTYPE html>
<html>
	<head>
		
	</head>
	<body style="margin:0px; padding:0px; background-color:#98ddca; color:#150e56;">
	
	<div style="background-color:#5eaaa8;  height:200px ; color:#150e56">
		<img src="images/uem.png"
		style=" 
		height:125px ; 
		width:125px; 
		margin:7px;
		float:left;
		"/>
		<h1 style="
		
		left:500px;
		position:relative; 
		margin-top:30px;
		float:left;
		">Welcome to UEM </h1><br><br><br><br>
		<h2 style="left:250px;
		
		position:relative; 
		margin-top:30px;
		float:left;">Good Education,Good Jobs</h2>
		
	</div>
	<div style="margin-top:15%;text-align:center; color:#150e56;">
		<h3 > Advancing Placements </h3>
		<h2> Please Wait While we Redirect you to our Page </h2>
		<footer> Not Redirected?? <a href="home.php"><em>Click Here</em></a></footer>
		</div>
		
	</body>
 </html>